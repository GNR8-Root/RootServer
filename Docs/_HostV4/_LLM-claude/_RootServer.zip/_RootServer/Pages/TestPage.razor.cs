﻿namespace RootServer.Pages
{
    public partial class TestUrl
    {
        private int currentCount = 0;

        private void IncrementCount()
        {
            currentCount++;
        }
    }
}