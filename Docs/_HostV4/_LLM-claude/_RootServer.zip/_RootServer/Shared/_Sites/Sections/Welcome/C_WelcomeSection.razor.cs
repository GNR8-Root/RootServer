﻿using System;
using AirtableApiClient;
using Blazorise;
using Microsoft.AspNetCore.Components;
using RootServer.Shared.Airtable;



namespace RootServer.Shared._Projects
{
	public partial class C_WelcomeSection
    {

        public C_WelcomeSection()
        {
            Class = "section-welcome";
        }
    }
}

