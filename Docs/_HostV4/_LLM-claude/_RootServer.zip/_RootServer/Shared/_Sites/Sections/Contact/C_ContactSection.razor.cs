﻿using System;
using AirtableApiClient;
using Blazorise;
using Microsoft.AspNetCore.Components;
using RootServer.Shared.Airtable;



namespace RootServer.Shared._Sites
{
	public partial class C_ContactSection
    {

        public C_ContactSection()
        {
            Class = "section-contact";
        }
    }
}

