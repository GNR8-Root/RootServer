﻿using System;



namespace RootServer.Shared._Core
{
	public enum StateVisibility
	{
        SetVisible,
        SetHidden
    }
}