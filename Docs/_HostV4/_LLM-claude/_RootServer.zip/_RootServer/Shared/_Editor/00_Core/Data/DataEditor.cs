﻿using System;
namespace RootServer.Shared._Editor
{
	public static class DataEditor
	{
        public static bool AccordionSingle = true;
    }
}

