﻿using System;
using Blazorise;
using Microsoft.AspNetCore.Components;


namespace RootServer.Shared._Editor
{
	public partial class P_LogCatcher
    {

    }
}

