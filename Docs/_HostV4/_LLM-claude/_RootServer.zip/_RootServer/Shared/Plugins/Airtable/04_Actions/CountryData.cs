﻿namespace RootServer.Shared.Airtable
{
    public class CountryData
    {
    }
}