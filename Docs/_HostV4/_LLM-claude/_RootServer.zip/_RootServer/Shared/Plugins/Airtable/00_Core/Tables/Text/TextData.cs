﻿using System;



namespace RootServer.Shared.Airtable
{
	public class TextData
    {
		public string? Name { get; set; }
        public string? En { get; set; }
        public string? Notes { get; set; }
        public string[]? Section { get; set; }
    }
}