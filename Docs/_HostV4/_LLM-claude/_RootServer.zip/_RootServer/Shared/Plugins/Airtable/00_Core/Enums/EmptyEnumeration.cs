﻿using System;
namespace RootServer.Shared.Airtable
{
    public enum SelectionType
    {
        workspace,
        table,
        row,
        record,
        group
    }
}

