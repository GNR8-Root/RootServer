﻿using System;



namespace RootServer.Shared.Airtable
{
	public class ContactData
    {
		public string? Name { get; set; }
        public string? Phone { get; set; }
        public string? PhoneIcon { get; set; }
        public string? Email { get; set; }
        public string? EmailIcon { get; set; }
        public string? Fb { get; set; }
        public string? FbIcon { get; set; }
        public string? Insta { get; set; }
        public string? InstaIcon { get; set; }
    }
}