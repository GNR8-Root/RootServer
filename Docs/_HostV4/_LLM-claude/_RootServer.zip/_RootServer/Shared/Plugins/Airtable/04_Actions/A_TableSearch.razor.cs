﻿using System;
using System.Data;
using System.Net.NetworkInformation;
using Blazorise;
using Microsoft.AspNetCore.Components;



namespace RootServer.Shared.Airtable
{
    public partial class A_TableSearch
    {
        //public class SearchData
        //{
        //    internal static Task<IEnumerable<Data>?> GetDataAsync()
        //    {
        //        throw new NotImplementedException();
        //    }
        //}

        //public class Data
        //{
        //    public string Name { get; set; } = "name";
        //    public string Iso { get; set; } = "val";
        //}


        //[Inject]
        //public SearchData? DataToSearch { get; set; }
        //public IEnumerable<Data>? DataSet;

        //protected override async Task OnInitializedAsync()
        //{

        //    DataSet = await SearchData.GetDataAsync();
        //    await base.OnInitializedAsync();
        //}
    }
}