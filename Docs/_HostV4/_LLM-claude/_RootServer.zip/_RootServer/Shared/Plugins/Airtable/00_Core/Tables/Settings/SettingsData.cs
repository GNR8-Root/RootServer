﻿using System;



namespace RootServer.Shared.Airtable
{
	public class SettingsData
    {
		public string? Name { get; set; }
        public string? Notes { get; set; }
    }
}