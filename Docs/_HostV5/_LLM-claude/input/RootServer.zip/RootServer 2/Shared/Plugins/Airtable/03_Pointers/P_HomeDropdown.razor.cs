﻿using System;
using AirtableApiClient;
using Blazorise;
using Microsoft.AspNetCore.Components;
using static RootServer.Shared._Core.CP_DropdownItem;



namespace RootServer.Shared.Airtable
{
	public partial class P_HomeDropdown
    {

    }
}