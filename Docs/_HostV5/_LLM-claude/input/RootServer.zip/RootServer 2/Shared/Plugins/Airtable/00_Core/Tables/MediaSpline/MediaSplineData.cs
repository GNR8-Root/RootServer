﻿using System;
using AirtableApiClient;



namespace RootServer.Shared.Airtable
{
	public class MediaSplineData : BaseMediaType
    {
    }
}