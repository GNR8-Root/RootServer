﻿using System;
using System.Net.NetworkInformation;
using Blazorise;
using Microsoft.AspNetCore.Components;


namespace RootServer.Shared.Airtable
{
    
	public partial class V_Workspace
    {

    }
}