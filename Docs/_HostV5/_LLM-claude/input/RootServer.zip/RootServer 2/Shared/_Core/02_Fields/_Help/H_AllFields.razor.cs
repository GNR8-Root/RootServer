﻿using System;
using AirtableApiClient;
using Microsoft.AspNetCore.Components;



namespace RootServer.Shared.Airtable
{
	public partial class H_AllFields
    {

        
    }
}