﻿using System;
using AirtableApiClient;
using Microsoft.AspNetCore.Components;
using RootServer.Shared.Airtable;



namespace RootServer.Shared._Sites
{
	public partial class Background_Spline
    {
        public Background_Spline()
		{

		}
	}
}

