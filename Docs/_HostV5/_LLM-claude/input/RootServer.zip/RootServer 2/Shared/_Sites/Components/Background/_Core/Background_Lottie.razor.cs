﻿using System;
using AirtableApiClient;
using Microsoft.AspNetCore.Components;
using RootServer.Shared.Airtable;



namespace RootServer.Shared._Sites
{
	public partial class Background_Lottie
    {
        public Background_Lottie()
		{
            /*
         * 
         * Loop="1" 
         * PlayDirectionForward="1" 
         * Autoplay="1" 
         * Renderer="svg" 
         * DefaultDuration="6" 
         * OverrideDuration="0"
         */
        }
    }
}

