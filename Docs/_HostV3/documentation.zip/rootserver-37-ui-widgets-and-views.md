# Widgets and Views

## 07_Widgets Layer

Minimal implementation in Shared/_Core/07_Widgets/:
- SurveyPrompt widget

Intended for layout containers combining multiple views.

## 08_View Layer

Folder exists in _Core but appears empty.

Intended for single or multiple view layouts.

Both layers require further development or may be more active in _Editor context.

[← Back to UI Index](rootserver-26-ui-index.md)

---
