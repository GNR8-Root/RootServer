# Panels and Navigation

## 09_Panels Layer

### _Core Status
Folder exists but empty.

### Airtable Plugin Panels
- PNL_Structure - Structure browser panel
- PNL_Selection - Selection inspector panel

Panels are high-level editor components grouping multiple views.

### Editor Environment

_Editor likely contains additional panels for:
- Workspace selection
- Table browsing
- Log viewing
- Property inspection

[← Back to UI Index](rootserver-26-ui-index.md)

---
