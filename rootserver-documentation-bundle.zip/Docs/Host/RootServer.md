# RootServer — Host Documentation

High-level documentation for the RootServer Host, aligned to project conventions and strict validation. Use the indices below to navigate Architecture, UI, and Appendix.

---

## Sections
- **[Base Index](./docsgen-00-base-index.md)** — Core concepts, conventions, terminology (Host scope)
- **[Architecture Index](./docsgen-12-arch-index.md)** — Host architecture, module/plugin system, performance, testing, deployment
- **[UI Index](./docsgen-26-ui-index.md)** — UI hierarchy model (Shared/_Sites), folder roles, prefixes, patterns
- **[Appendix Index](./docsgen-39-appendix-index.md)** — Project structure, risks and vulnerabilities, duplicate JSON cleanup task

---

## Scope & Boundaries (Host)
- Coordinates Modules and Plugins; Host should not depend on Plugins
- Module ↔ Module direct references allowed; Plugins may reference Modules
- Planned Plugin ↔ Plugin interaction via Node system (experimental)

---

**Back navigation:** **[Preflight Summary](./00-preflight-summary.md)**

---
